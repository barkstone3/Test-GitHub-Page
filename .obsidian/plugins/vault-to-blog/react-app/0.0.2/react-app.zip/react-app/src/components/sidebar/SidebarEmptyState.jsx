const SidebarEmptyState = () => {
  return (
    <div className="workspace-sidedock-empty-state" style={{display: "none"}}>
      <p className="u-muted">아직 내용이 없습니다.</p>
    </div>
  )
};

export default SidebarEmptyState;